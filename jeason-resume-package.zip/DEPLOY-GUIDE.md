# Jeason 网页简历 - 部署方案

## 项目文件清单

| 文件 | 说明 |
|------|------|
| index.html | 首页 - 宇宙背景 + 弹性字母交互 |
| profile.html | 基本信息 |
| internship.html | 实习经历 |
| projects.html | 项目经历 |
| practice.html | 实践经历 |
| skills.html | 技能展示 |
| resume.html | 传统简历页 |

## 特性

- 纯静态 HTML/CSS/JS，无需后端服务器
- 无外部依赖（无 CDN、无 npm 包）
- 自包含：所有 CSS 和 JS 内嵌在 HTML 中
- 宇宙粒子背景基于 Canvas，无图片依赖
- 弹性字母交互使用 picsum.photos（需网络）
- 响应式设计：适配 640px/768px/900px 断点

---

## 方案一：GitHub Pages（推荐，免费）

### 步骤

1. 创建 GitHub 仓库，如 `jeason-resume`
2. 将所有 HTML 文件推送至仓库根目录
3. 在仓库 Settings > Pages 中：
   - Source: Deploy from a branch
   - Branch: `main`，目录: `/ (root)`
4. 等待 1-2 分钟，访问 `https://<username>.github.io/jeason-resume/`

### 自定义域名（可选）

- 在 Pages 设置中填入自定义域名
- 在域名 DNS 添加 CNAME 记录指向 `<username>.github.io`
- 仓库中创建 `CNAME` 文件，内容为域名

---

## 方案二：Vercel（推荐，免费）

### 步骤

1. 注册 Vercel 账号（支持 GitHub 登录）
2. New Project > Import Git Repository > 选择 `jeason-resume`
3. Framework Preset: Other（纯静态）
4. Build Command: 无，Output Directory: `./`
5. 部署完成后获得 `https://jeason-resume-xxx.vercel.app`
6. 可在 Settings > Domains 绑定自定义域名

---

## 方案三：Netlify（免费）

### 步骤

1. 注册 Netlify 账号
2. Sites > Add new site > Deploy manually
3. 将整个项目文件夹拖入上传区域
4. 或选择 "Import from Git" 连接 GitHub 仓库
5. 获得 `https://random-name.netlify.app`
6. Site settings > Domain management 可绑定自定义域名

---

## 方案四：腾讯云 CloudBase / 阿里云 OSS

### 腾讯云 CloudBase

1. 开通 CloudBase 静态网站托管
2. 上传全部 HTML 文件至 hosting 根目录
3. 获得 `https://env-id-xxxx.tcloudbaseapp.com`
4. 可绑定自定义域名

### 阿里云 OSS

1. 创建 OSS Bucket，开启静态网站托管
2. 上传全部 HTML 文件
3. 默认首页设为 `index.html`
4. 可绑定自定义域名（需备案）

---

## 方案五：本地预览 / 离线分享

### 直接打开

双击 `index.html` 在浏览器中打开，其他页面通过导航链接跳转。

### 本地 HTTP 服务（可选）

```bash
# Python 方式
python -m http.server 8080

# Node.js 方式
npx serve .
```

访问 `http://localhost:8080`

---

## 方案六：打包为 PDF

使用浏览器打印功能（Ctrl+P）将每个页面保存为 PDF，合并后可作为附件发送。

---

## 推荐方案总结

| 方案 | 费用 | 速度 | 难度 | 推荐场景 |
|------|------|------|------|----------|
| GitHub Pages | 免费 | 中 | 低 | 个人展示、长期维护 |
| Vercel | 免费 | 快 | 低 | 快速部署、自动更新 |
| Netlify | 免费 | 快 | 低 | 拖拽部署、简单易用 |
| CloudBase/OSS | 付费 | 国内快 | 中 | 国内加速、企业域名 |
| 本地打开 | 免费 | 即时 | 无 | 离线演示、面试现场 |

**首选推荐：GitHub Pages** — 免费、稳定、与版本控制天然集成，适合简历长期在线展示。

---

## 注意事项

1. **picsum.photos 依赖**：首页字母点击预览图片依赖 picsum.photos 服务，需联网。如需离线，可替换为本地图片路径。
2. **页面间导航**：采用相对路径，所有文件需在同一目录下部署。
3. **浏览器兼容**：Chrome 90+、Firefox 88+、Safari 14+、Edge 90+ 均支持。IE 不支持。
4. **移动端适配**：640px 以下断点已优化，手机端可正常浏览。
